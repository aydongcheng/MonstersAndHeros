//the creator of merchandise
public interface MerchandiseCreator {
    public Merchandise createMercandise(String infoList);
}
