//the ability to level up
public interface LevelUp {
    public void levelUpTo(int Level);
}
