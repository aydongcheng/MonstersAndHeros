//the creator of monster
public interface MonsterCreator {
    public Monster createMonster();
}
