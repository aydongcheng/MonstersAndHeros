//the ability of fight with others
public interface Fightable{
    public int attack();
    public int getHurt(int damage);
}
