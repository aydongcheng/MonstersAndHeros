public class Main {
    //main method to start the game
    public static void main(String[] args) {
        MAHGame game = new MAHGame();
        game.start();
    }
}
