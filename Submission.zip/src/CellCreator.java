// the interface of factory pattern to create cell of board
public interface CellCreator {
    public Cell createCell();
}
